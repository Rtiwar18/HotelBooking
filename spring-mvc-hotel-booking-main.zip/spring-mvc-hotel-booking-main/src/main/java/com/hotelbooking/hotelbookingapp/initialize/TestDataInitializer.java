package com.hotelbooking.hotelbookingapp.initialize;

import com.hotelbooking.hotelbookingapp.model.*;
import com.hotelbooking.hotelbookingapp.repository.*;
import com.hotelbooking.hotelbookingapp.model.enums.RoleType;
import com.hotelbooking.hotelbookingapp.model.enums.RoomType;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.dao.DataAccessException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;

@Component
@RequiredArgsConstructor
@Slf4j
public class TestDataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final AdminRepository adminRepository;
    private final CustomerRepository customerRepository;
    private final HotelManagerRepository hotelManagerRepository;
    private final PasswordEncoder passwordEncoder;
    private final AddressRepository addressRepository;
    private final HotelRepository hotelRepository;
    private final AvailabilityRepository availabilityRepository;

    @Override
    @Transactional
    public void run(String... args) {

        try {
            log.warn("Checking if test data persistence is required...");

            if (roleRepository.count() == 0 && userRepository.count() == 0) {
                log.info("Initiating test data persistence");

                Role adminRole = new Role(RoleType.ADMIN);
                Role customerRole = new Role(RoleType.CUSTOMER);
                Role hotelManagerRole = new Role(RoleType.HOTEL_MANAGER);

                roleRepository.save(adminRole);
                roleRepository.save(customerRole);
                roleRepository.save(hotelManagerRole);
                log.info("Role data persisted");

                User user1 = User.builder().username("admin@gmail.com").password(passwordEncoder.encode("1")).name("Admin").lastName("Admin").role(adminRole).build();
                User user2 = User.builder().username("santosh@gmail.com").password(passwordEncoder.encode("1")).name("Santosh").lastName("Chaurasiya").role(customerRole).build();
                User user3 = User.builder().username("naveen@gmail.com").password(passwordEncoder.encode("1")).name("Naveen").lastName("Singh").role(hotelManagerRole).build();
                User user4 = User.builder().username("raj@gmail.com").password(passwordEncoder.encode("1")).name("Raj Kumar").lastName("Tiwari").role(hotelManagerRole).build();

                userRepository.save(user1);
                userRepository.save(user2);
                userRepository.save(user3);
                userRepository.save(user4);

                Admin admin1 = Admin.builder().user(user1).build();
                Customer c1 = Customer.builder().user(user2).build();
                HotelManager hm1 = HotelManager.builder().user(user3).build();
                HotelManager hm2 = HotelManager.builder().user(user4).build();

                adminRepository.save(admin1);
                customerRepository.save(c1);
                hotelManagerRepository.save(hm1);
                hotelManagerRepository.save(hm2);
                log.info("User data persisted");

                Address addressInd1 = Address.builder().addressLine("Paras Tierea, 201305").city("Uttar Pradesh")
                        .country("India").build();
                Address addressInd2 = Address.builder().addressLine("Paras Tierea, 201305").city("Uttar Pradesh")
                        .country("India").build();
                Address addressInd3 = Address.builder().addressLine("Paras Tierea, 201305").city("Uttar Pradesh")
                        .country("India").build();

                Address addressNoida1 = Address.builder().addressLine("Paras Tierea, 201305").city("Uttar Pradesh")
                        .country("India").build();
                Address addressNoida2 = Address.builder().addressLine("Paras Tierea, 201305").city("Uttar Pradesh")
                        .country("India").build();
                Address addressNoida3 = Address.builder().addressLine("Paras Tierea, 201305").city("Uttar Pradesh")
                        .country("India").build();

                addressRepository.save(addressInd1);
                addressRepository.save(addressInd2);
                addressRepository.save(addressInd3);
                addressRepository.save(addressNoida1);
                addressRepository.save(addressNoida2);
                addressRepository.save(addressNoida3);

                Hotel hotelIst1 = Hotel.builder().name("Raddison Blue Greater Noida")
                        .address(addressInd1).hotelManager(hm1).build();
                Hotel hotelIst2 = Hotel.builder().name("Hotel Higway King Noida")
                        .address(addressInd2).hotelManager(hm1).build();
                Hotel hotelIst3 = Hotel.builder().name("Hyaat regency Noida")
                        .address(addressInd3).hotelManager(hm1).build();

                Hotel hotelNoida1 = Hotel.builder().name("Golden Tulip Noida")
                        .address(addressNoida1).hotelManager(hm2).build();
                Hotel hotelNoida2 = Hotel.builder().name("Holiday Inn Noida")
                        .address(addressNoida2).hotelManager(hm2).build();
                Hotel hotelBerlin3 = Hotel.builder().name("InterContinental Noida")
                        .address(addressNoida3).hotelManager(hm2).build();

                Room singleRoomInd1 = Room.builder().roomType(RoomType.SINGLE)
                        .pricePerNight(370).roomCount(35).hotel(hotelIst1).build();
                Room doubleRoomInd1 = Room.builder().roomType(RoomType.DOUBLE)
                        .pricePerNight(459).roomCount(45).hotel(hotelIst1).build();

                Room singleRoomInd2 = Room.builder().roomType(RoomType.SINGLE)
                        .pricePerNight(700).roomCount(25).hotel(hotelIst2).build();
                Room doubleRoomInd2 = Room.builder().roomType(RoomType.DOUBLE)
                        .pricePerNight(890).roomCount(30).hotel(hotelIst2).build();

                Room singleRoomInd3 = Room.builder().roomType(RoomType.SINGLE)
                        .pricePerNight(691).roomCount(30).hotel(hotelIst3).build();
                Room doubleRoomInd3 = Room.builder().roomType(RoomType.DOUBLE)
                        .pricePerNight(800).roomCount(75).hotel(hotelIst3).build();

                Room singleRoomNoida1 = Room.builder().roomType(RoomType.SINGLE)
                        .pricePerNight(120.0).roomCount(25).hotel(hotelNoida1).build();
                Room doubleRoomNoida1 = Room.builder().roomType(RoomType.DOUBLE)
                        .pricePerNight(250.0).roomCount(15).hotel(hotelNoida1).build();

                Room singleRoomNoida2 = Room.builder().roomType(RoomType.SINGLE)
                        .pricePerNight(300).roomCount(50).hotel(hotelNoida2).build();
                Room doubleRoomNoida2 = Room.builder().roomType(RoomType.DOUBLE)
                        .pricePerNight(400).roomCount(50).hotel(hotelNoida2).build();

                Room singleRoomNoida3 = Room.builder().roomType(RoomType.SINGLE)
                        .pricePerNight(179).roomCount(45).hotel(hotelBerlin3).build();
                Room doubleRoomNoida3 = Room.builder().roomType(RoomType.DOUBLE)
                        .pricePerNight(256).roomCount(25).hotel(hotelBerlin3).build();

                hotelIst1.getRooms().addAll(Arrays.asList(singleRoomInd1,doubleRoomInd1));
                hotelIst2.getRooms().addAll(Arrays.asList(singleRoomInd2,doubleRoomInd2));
                hotelIst3.getRooms().addAll(Arrays.asList(singleRoomInd3,doubleRoomInd3));
                hotelNoida1.getRooms().addAll(Arrays.asList(singleRoomNoida1,doubleRoomNoida1));
                hotelNoida2.getRooms().addAll(Arrays.asList(singleRoomNoida2,doubleRoomNoida2));
                hotelBerlin3.getRooms().addAll(Arrays.asList(singleRoomNoida3,doubleRoomNoida3));

                hotelRepository.save(hotelIst1);
                hotelRepository.save(hotelIst2);
                hotelRepository.save(hotelIst3);
                hotelRepository.save(hotelNoida1);
                hotelRepository.save(hotelNoida2);
                hotelRepository.save(hotelBerlin3);
                log.info("Hotel data persisted");

                Availability av1Noida1 = Availability.builder().hotel(hotelNoida1)
                        .date(LocalDate.of(2023,10,5)).room(singleRoomNoida1).availableRooms(5).build();
                Availability av2Noida1 = Availability.builder().hotel(hotelNoida1)
                        .date(LocalDate.of(2023,10,12)).room(doubleRoomNoida1).availableRooms(7).build();

                availabilityRepository.save(av1Noida1);
                availabilityRepository.save(av2Noida1);
                log.info("Availability data persisted");

            } else {
                log.info("Test data persistence is not required");
            }
            log.warn("App ready");
        } catch (DataAccessException e) {
            log.error("Exception occurred during data persistence: " + e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected exception occurred: " + e.getMessage());
        }
    }
}
