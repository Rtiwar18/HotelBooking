package com.hotelbooking.hotelbookingapp.model.enums;

public enum RoleType {

    ADMIN,
    CUSTOMER,
    HOTEL_MANAGER
}
