package com.hotelbooking.hotelbookingapp.model.enums;

public enum Currency {
    USD,
    EUR,
    TRY
}
