package com.hotelbooking.hotelbookingapp.model.enums;

public enum PaymentMethod {
    CREDIT_CARD,
    DEBIT_CARD,
    PAYPAL
}
